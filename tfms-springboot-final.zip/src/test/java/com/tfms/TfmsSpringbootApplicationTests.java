package com.tfms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfmsSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
